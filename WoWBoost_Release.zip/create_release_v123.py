import os
import json
import urllib.request
import urllib.error

token = "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"
owner = "westland"
repo = "BoostDashboard"
tag = "v1.23"
zip_path = "WoWBoost_Release.zip"

headers = {
    "Authorization": f"token {token}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "ReleaseBuilder"
}

# 1. Create the release
release_url = f"https://api.github.com/repos/{owner}/{repo}/releases"
data = {
    "tag_name": tag,
    "target_commitish": "main",
    "name": f"WoW Boost Lead System {tag}",
    "body": (
        "Release v1.23 containing the fully integrated Streamlit dashboard. "
        "Installer automatically creates a Windows Desktop shortcut with an appropriate rocket icon."
    ),
    "draft": False,
    "prerelease": False
}

req = urllib.request.Request(
    release_url, 
    data=json.dumps(data).encode("utf-8"), 
    headers=headers,
    method="POST"
)

print(f"Creating release {tag} on GitHub...")
try:
    with urllib.request.urlopen(req) as response:
        res_data = response.read()
        release_json = json.loads(res_data.decode("utf-8"))
        release_id = release_json["id"]
        print(f"Successfully created release. ID: {release_id}")
except urllib.error.HTTPError as e:
    print(f"Failed to create release: {e.code}")
    print(e.read().decode("utf-8"))
    exit(1)

# 2. Upload the ZIP asset
upload_url = f"https://uploads.github.com/repos/{owner}/{repo}/releases/{release_id}/assets?name={os.path.basename(zip_path)}"
print(f"Uploading asset {zip_path} to release...")

upload_headers = headers.copy()
upload_headers["Content-Type"] = "application/zip"

with open(zip_path, "rb") as f:
    zip_binary = f.read()

req_upload = urllib.request.Request(
    upload_url,
    data=zip_binary,
    headers=upload_headers,
    method="POST"
)

try:
    with urllib.request.urlopen(req_upload) as response:
        print(f"Release {tag} created and WoWBoost_Release.zip asset uploaded successfully!")
except urllib.error.HTTPError as e:
    print(f"Failed to upload asset: {e.code}")
    print(e.read().decode("utf-8"))
    exit(1)
