import os
import urllib.request
import urllib.error
import json

token = "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"
owner = "westland"
repo = "BoostDashboard"
release_id = 349088969
zip_path = "WoWBoost_Release.zip"

headers = {
    "Authorization": f"token {token}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "ReleaseBuilder"
}

# 1. Fetch release assets to locate the ID of WoWBoost_Release.zip
assets_url = f"https://api.github.com/repos/{owner}/{repo}/releases/{release_id}/assets"
req_assets = urllib.request.Request(assets_url, headers=headers, method="GET")

asset_id = None
try:
    print("Fetching active release assets list...")
    with urllib.request.urlopen(req_assets) as response:
        assets = json.loads(response.read().decode("utf-8"))
        for asset in assets:
            if asset["name"] == os.path.basename(zip_path):
                asset_id = asset["id"]
                break
except Exception as e:
    print(f"Failed to query assets: {e}")

# If found, delete the old asset
if asset_id:
    delete_url = f"https://api.github.com/repos/{owner}/{repo}/releases/assets/{asset_id}"
    req_del = urllib.request.Request(delete_url, headers=headers, method="DELETE")
    print(f"Deleting old release asset ID: {asset_id}...")
    try:
        with urllib.request.urlopen(req_del) as response:
            print("Old asset deleted successfully.")
    except urllib.error.HTTPError as e:
        print(f"Failed to delete old asset: {e.code}")
        print(e.read().decode("utf-8"))
        exit(1)
else:
    print("No existing asset found to delete. Uploading directly.")

# 2. Upload the new asset
upload_url = f"https://uploads.github.com/repos/{owner}/{repo}/releases/{release_id}/assets?name={os.path.basename(zip_path)}"
print(f"Uploading new asset {zip_path}...")
upload_headers = headers.copy()
upload_headers["Content-Type"] = "application/zip"

with open(zip_path, "rb") as f:
    zip_data = f.read()

req_upload = urllib.request.Request(upload_url, data=zip_data, headers=upload_headers, method="POST")
try:
    with urllib.request.urlopen(req_upload) as response:
        print("New asset uploaded successfully!")
except urllib.error.HTTPError as e:
    print(f"Failed to upload new asset: {e.code}")
    print(e.read().decode("utf-8"))
    exit(1)
